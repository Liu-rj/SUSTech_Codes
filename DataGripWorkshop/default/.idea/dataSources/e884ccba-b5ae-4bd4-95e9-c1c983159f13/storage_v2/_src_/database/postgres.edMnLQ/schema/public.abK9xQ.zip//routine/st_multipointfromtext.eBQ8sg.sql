create function st_multipointfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT public.ST_MPointFromText($1)
$$;

alter function st_multipointfromtext(text) owner to postgres;

