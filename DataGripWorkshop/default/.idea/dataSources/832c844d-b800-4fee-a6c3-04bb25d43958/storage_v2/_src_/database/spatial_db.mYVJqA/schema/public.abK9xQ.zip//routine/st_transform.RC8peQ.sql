create function st_transform(geom geometry, to_proj text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.postgis_transform_geometry($1, proj4text, $2, 0)
FROM spatial_ref_sys WHERE srid=public.ST_SRID($1);
$$;

comment on function st_transform(geometry, text) is 'args: geom, to_proj - Return a new geometry with its coordinates transformed to a different spatial reference.';

alter function st_transform(geometry, text) owner to lrj;

