create function st_mapalgebrafct(rast1 raster, rast2 raster, tworastuserfunc regprocedure, pixeltype text DEFAULT NULL::text, extenttype text DEFAULT 'INTERSECTION'::text, VARIADIC userargs text[] DEFAULT NULL::text[]) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.ST_mapalgebrafct($1, 1, $2, 1, $3, $4, $5, VARIADIC $6)
$$;

alter function st_mapalgebrafct(raster, raster, regprocedure, text, text, text[]) owner to fwb;

