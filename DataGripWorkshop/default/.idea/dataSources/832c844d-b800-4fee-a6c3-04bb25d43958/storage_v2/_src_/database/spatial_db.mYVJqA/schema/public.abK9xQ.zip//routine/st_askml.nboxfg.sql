create function st_askml(geom geometry, maxdecimaldigits integer DEFAULT 15) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_AsKML(2, ST_Transform($1,4326), $2, null);
$$;

comment on function st_askml(geometry, integer) is 'args: geom, maxdecimaldigits=15 - Return the geometry as a KML element. Several variants. Default version=2, default precision=15';

alter function st_askml(geometry, integer) owner to lrj;

