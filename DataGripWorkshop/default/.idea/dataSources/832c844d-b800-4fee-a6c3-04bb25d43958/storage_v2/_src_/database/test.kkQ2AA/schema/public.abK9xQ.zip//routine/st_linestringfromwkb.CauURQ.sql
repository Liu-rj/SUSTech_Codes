create function st_linestringfromwkb(bytea) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'LINESTRING'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END

$$;

comment on function st_linestringfromwkb(bytea) is 'args: WKB - Makes a geometry from WKB with the given SRID.';

alter function st_linestringfromwkb(bytea) owner to fwb;

