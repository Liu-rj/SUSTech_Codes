create function st_mapalgebrafct(rast raster, pixeltype text, onerastuserfunc regprocedure, VARIADIC args text[]) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.ST_mapalgebrafct($1, 1, $2, $3, VARIADIC $4)
$$;

alter function st_mapalgebrafct(raster, text, regprocedure, text[]) owner to lrj;

