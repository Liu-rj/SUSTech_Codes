create function st_line_interpolate_point(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._postgis_deprecate('ST_Line_Interpolate_Point', 'ST_LineInterpolatePoint', '2.1.0');
    SELECT public.ST_LineInterpolatePoint($1, $2);
$$;

alter function st_line_interpolate_point(geometry, double precision) owner to postgres;

