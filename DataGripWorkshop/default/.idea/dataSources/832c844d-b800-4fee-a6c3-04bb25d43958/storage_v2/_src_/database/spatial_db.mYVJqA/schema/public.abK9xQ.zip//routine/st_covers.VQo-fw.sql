create function st_covers(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT ST_Covers($1::public.geometry, $2::public.geometry);
$$;

alter function st_covers(text, text) owner to lrj;

