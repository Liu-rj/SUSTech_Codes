create function box3d(raster) returns box3d
    immutable
    strict
    parallel safe
    language sql
as
$$
select box3d( public.ST_convexhull($1))
$$;

alter function box3d(raster) owner to postgres;

