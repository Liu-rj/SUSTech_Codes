create function st_approxhistogram(rastertable text, rastercolumn text, nband integer, sample_percent double precision, bins integer, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
    stable
    strict
    language sql
as
$$
SELECT public._ST_histogram($1, $2, $3, TRUE, $4, $5, $6, $7)
$$;

alter function st_approxhistogram(text, text, integer, double precision, integer, double precision[], boolean, out double precision, out double precision, out bigint, out double precision) owner to postgres;

