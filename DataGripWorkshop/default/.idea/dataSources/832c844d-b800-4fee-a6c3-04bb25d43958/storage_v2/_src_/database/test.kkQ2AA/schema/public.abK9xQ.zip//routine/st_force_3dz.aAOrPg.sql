create function st_force_3dz(geometry) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._postgis_deprecate('ST_Force_3dz', 'ST_Force3DZ', '2.1.0');
    SELECT public.ST_Force3DZ($1);
$$;

alter function st_force_3dz(geometry) owner to fwb;

