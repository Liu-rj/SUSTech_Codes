create function st_setvalues(rast raster, nband integer, x integer, y integer, newvalueset double precision[], nosetvalue double precision, keepnodata boolean DEFAULT false) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public._ST_setvalues($1, $2, $3, $4, $5, NULL, TRUE, $6, $7)
$$;

comment on function st_setvalues(raster, integer, integer, integer, double precision[], double precision, boolean) is 'args: rast, nband, columnx, rowy, newvalueset, nosetvalue, keepnodata=FALSE - Returns modified raster resulting from setting the values of a given band.';

alter function st_setvalues(raster, integer, integer, integer, double precision[], double precision, boolean) owner to postgres;

