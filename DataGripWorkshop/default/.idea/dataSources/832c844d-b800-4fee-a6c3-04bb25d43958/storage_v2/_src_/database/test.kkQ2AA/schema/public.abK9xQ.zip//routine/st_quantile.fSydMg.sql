create function st_quantile(rastertable text, rastercolumn text, nband integer, exclude_nodata_value boolean, quantile double precision) returns double precision
    stable
    strict
    language sql
as
$$
SELECT ( public._ST_quantile($1, $2, $3, $4, 1, ARRAY[$5]::double precision[])).value
$$;

alter function st_quantile(text, text, integer, boolean, double precision) owner to fwb;

