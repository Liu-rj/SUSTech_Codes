create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$
SELECT '2021-04-01 03:28:53'::text AS version
$$;

comment on function postgis_scripts_build_date() is 'Returns build date of the PostGIS scripts.';

alter function postgis_scripts_build_date() owner to lrj;

