create function st_quantile(rast raster, nband integer, quantiles double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_quantile($1, $2, TRUE, 1, $3)
$$;

comment on function st_quantile(raster, integer, double precision[], out double precision, out double precision) is 'args: rast, nband, quantiles - Compute quantiles for a raster or raster table coverage in the context of the sample or population. Thus, a value could be examined to be at the rasters 25%, 50%, 75% percentile.';

alter function st_quantile(raster, integer, double precision[], out double precision, out double precision) owner to fwb;

